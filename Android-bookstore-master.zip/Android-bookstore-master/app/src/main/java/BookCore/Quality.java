package BookCore;

import java.util.List;

public class Quality {
    String description;
    List<Answer> answers;

}
