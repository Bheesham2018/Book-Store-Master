package util;

public class FontName {
    public static String IranSans = "fonts/IRANSans.ttf";
    public static String IranSansBold = "fonts/IRANSans_Bold.ttf";
}
