package account;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;

import ir.debook.debook.R;

public class SignIn extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
    }
}
