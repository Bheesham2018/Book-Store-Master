package MessageCore;

public enum MessageType {
    BOOK,
    EMAIL,
    DOWNLOADFILE,
    URL,
    NONE
}
