package components;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;

public class ImageUploader extends RelativeLayout {


    public ImageUploader(Context context, AttributeSet attrs) {
        super(context, attrs);

    }
}
